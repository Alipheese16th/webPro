package quiz_interfaces;

public interface JobImpl {
	public void job();
}
