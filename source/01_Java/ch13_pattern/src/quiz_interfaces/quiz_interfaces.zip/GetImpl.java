package quiz_interfaces;

public interface GetImpl {
	public void get();
}
