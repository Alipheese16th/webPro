package com.kist.portal.test.time.service;

import com.kist.portal.test.time.dto.TestLocationDto;

import java.util.List;

public interface TestCityTimeService {

    List<TestLocationDto> selectLocationList(TestLocationDto param);

    TestLocationDto saveLocation(TestLocationDto param);
}
