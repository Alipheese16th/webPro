package com.kist.portal.test.time.service;

import com.kist.portal.common.utils.Constant;
import com.kist.portal.test.time.dto.TestLocationDto;
import com.kist.portal.test.time.mapper.TestCityTimeMapper;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TestCityTimeServiceImpl implements TestCityTimeService {

	@NonNull
	private final TestCityTimeMapper mapper;

	@Override
	public List<TestLocationDto> selectLocationList(TestLocationDto param) {
		return mapper.selectLocationList(param);
	}

	@Override
	public TestLocationDto saveLocation(TestLocationDto param) {
		int resultCnt = 0;

		if (param.getInsertList() != null && param.getInsertList().size() > 0) {
			for(TestLocationDto insertDto: param.getInsertList()) {
				resultCnt += mapper.insertLocation(insertDto);
			}
		}

		if (param.getUpdateList() != null && param.getUpdateList().size() > 0) {
			for(TestLocationDto updateDto: param.getUpdateList()) {
				resultCnt += mapper.updateLocation(updateDto);
			}
		}

		if (param.getDeleteList() != null && param.getDeleteList().size() > 0) {
			for(TestLocationDto deleteDto: param.getDeleteList()) {
				resultCnt += mapper.deleteLocation(deleteDto);
			}
		}

		param.setResultMsg(resultCnt > 0 ? Constant.SUCCESS : Constant.FAIL);
		return param;
	}
}
