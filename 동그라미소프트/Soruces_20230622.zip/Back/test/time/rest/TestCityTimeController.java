package com.kist.portal.test.time.rest;

import com.kist.portal.test.time.dto.TestLocationDto;
import com.kist.portal.test.time.service.TestCityTimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/test")
public class TestCityTimeController {

	@Autowired
	private TestCityTimeService cityService;

	@GetMapping("/location")
	public ResponseEntity<List<TestLocationDto>> selectLocationList(@ModelAttribute TestLocationDto param) {
		return new ResponseEntity<>(cityService.selectLocationList(param), HttpStatus.OK);
	}

	@PostMapping("/location/save")
	@Transactional
	public ResponseEntity<?> saveLocation(@RequestBody TestLocationDto param) {
		return new ResponseEntity<>(cityService.saveLocation(param), HttpStatus.OK);
	}
}
