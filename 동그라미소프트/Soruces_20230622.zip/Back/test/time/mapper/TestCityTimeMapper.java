package com.kist.portal.test.time.mapper;

import com.kist.portal.test.time.dto.TestLocationDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TestCityTimeMapper {

    List<TestLocationDto> selectLocationList(TestLocationDto param);

    int insertLocation(TestLocationDto param);

    int updateLocation(TestLocationDto param);

    int deleteLocation(TestLocationDto param);
}
