package com.kist.portal.test.time.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TestLocationDto {
    private String locKey;
    private String locCd;
    private String locTypeCd;
    private String upLocKey;
    private String locNm;
    private String locTimeZoneCd;
    private String gmtVal;
    private String arryOrd;
    private String resultMsg;

    private List<TestLocationDto> insertList;
    private List<TestLocationDto> updateList;
    private List<TestLocationDto> deleteList;
}
