<template>
  <div>
    <div class="location">
      <!--테스트 메뉴--><!--사용자 관리-->
      <span>Home > {{ $t('테스트 메뉴') }} > {{ $t('업체지역 관리') }}</span>
    </div>
    <div class="work_title">
      <h2>{{ $t('업체지역 조회') }}</h2>
    </div>
    <div class="realgrid_container">
      <v-row>
        <v-col cols="5">
          <div class="realgrid_container">
            <div class="sub_title">
              <h3>{{ $t('업체 목록') }}</h3>
            </div>
            <div class="grid_header">
              <!--총--><!--건-->
              <div class="grid_header_left">{{ $t('총') }} {{ totalCompanyCount }}{{ $t('건') }}</div>
              <div>
                <v-btn color="" outlined height="28" @click="onClickAddCompany()">{{ $t('추가') }}</v-btn>
                <v-btn color="" outlined height="28" @click="onClickDelCompany()">{{ $t('삭제') }}</v-btn>
              </div>
            </div>
            <div id="companygrid" style="width: 100%; height: 615px"></div>
          </div>
        </v-col>
        <v-col cols="7 shuttle_padd">
          <div class="realgrid_container">
            <div class="sub_title">
              <h3>{{ $t('국가 목록') }}</h3>
            </div>
            <div class="grid_header">
              <!--총--><!--건-->
              <div class="grid_header_left">{{ $t('총') }} {{ totalNationCount }}{{ $t('건') }}</div>
              <div>
                <v-btn color="" outlined height="28" @click="onClickAddNation()">{{ $t('추가') }}</v-btn>
                <v-btn color="" outlined height="28" @click="onClickDelNation()">{{ $t('삭제') }}</v-btn>
              </div>
            </div>
            <div id="nationgrid" style="width: 100%; height: 250px"></div>
          </div>
          <div class="group_padd" />
          <div class="realgrid_container">
            <div class="sub_title">
              <h3>{{ $t('도시 목록') }}</h3>
            </div>
            <div class="grid_header">
              <!--총--><!--건-->
              <div class="grid_header_left">{{ $t('총') }} {{ totalCityCount }}{{ $t('건') }}</div>
              <div>
                <v-btn color="" outlined height="28" @click="onClickAddCity()">{{ $t('추가') }}</v-btn>
                <v-btn color="" outlined height="28" @click="onClickDelCity()">{{ $t('삭제') }}</v-btn>
              </div>
            </div>
            <div id="citygrid" style="width: 100%; height: 250px"></div>
          </div>
        </v-col>
      </v-row>
    </div>
    <div class="group_padd"></div>
    <div class="container_button">
      <!--저장-->
      <v-btn depressed width="120" color="primary" height="40" @click="onClickSave">{{ $t('저장') }}</v-btn>
    </div>
  </div>
</template>

<script>
import { GridView, LocalDataProvider, ValueType } from 'realgrid'

export default {
  meta: {
    title: '사용자 관리',
  },
  components: {
  },
  data() {
    return {
      codeList: ['CO00000003', 'CO00000004'],
      codes: {
        CO00000003: [{ cd: '', cd_nm: '' }],
        CO00000004: [{ cd: '', cd_nm: '' }],
      },
      selCO00000003: {
        cd: [],
        cd_nm: [],
      },
      selCO00000004: {
        cd: [],
        cd_nm: [],
      },

      totalCompanyCount: 0,
      totalNationCount: 0,
      totalCityCount: 0,
      gridCompany: {
        dataProvider: null,
        gridView: null,
        field: [],
        rowData: []
      },
      gridNation: {
        dataProvider: null,
        gridView: null,
        field: [],
        rowData: []
      },
      gridCity: {
        dataProvider: null,
        gridView: null,
        field: [],
        rowData: []
      },

      selectedCompanyKey: '',
      selectedNationKey: '',
      testIndex: 0,
    }
  },
  async beforePageLeave(tab, type) {
  },
  created() {
  },
  mounted() {
    this.loadCodeList()
  },
  computed: {
    selectedCompanyIndex() {
      if (this.selectedCompanyKey !== null && this.selectedCompanyKey !== '') {
        const selectedIndex = this.gridCompany.dataProvider.searchDataRow({fields:['locKey'], values: [this.selectedCompanyKey]});
        return selectedIndex
      }
      return 0
    },
    selectedNationIndex() {
      if (this.selectedNationKey !== null && this.selectedNationKey !== ''
        && this.selectedCompanyKey !== null && this.selectedCompanyKey !== '') {
        const selectedIndex = this.gridNation.dataProvider.searchDataRow({fields:['locKey'], values: [this.selectedNationKey]});
        return selectedIndex
      }
      return 0
    },
  },
  methods: {
    //region REST API
    async loadCodeList() {
      await this.$axios.$get(`/api/v1/comm/comm-cd`, { params: this.codeList }).then((res) => {
        this.codes = res;

        this.selCO00000003.cd.push('');
        this.selCO00000003.cd_nm.push('SELECT');
        res.CO00000003.forEach((i) => {
          this.selCO00000003.cd.push(i.cd);
          this.selCO00000003.cd_nm.push(i.cd_nm);
        });

        this.selCO00000004.cd.push('');
        this.selCO00000004.cd_nm.push('SELECT');
        res.CO00000004.forEach((i) => {
          this.selCO00000004.cd.push(i.cd);
          this.selCO00000004.cd_nm.push(i.cd_nm);
        });

        this.initCompanyGrid()
        this.initNationGrid()
        this.initCityGrid()

        this.loadInitData()
      }).catch((err) => {
        // eslint-disable-next-line no-console
        console.log(err);
      });
    },
    async loadInitData() {
      await this.loadCompanyList()
    },
    async loadCompanyList() {
      const params = {
        locTypeCd: 'CPN',
      }
      const rows = await this.$axios.$get(`/api/v1/test/location`, { params })

      this.gridCompany.rowData = rows

      this.gridCompany.dataProvider.setRows(this.gridCompany.rowData)
      this.gridCompany.gridView.refresh()
      this.gridCompany.gridView.setTopItem(this.selectedCompanyIndex)

      this.totalCompanyCount = this.gridCompany.gridView.getItemCount()
      if (this.totalCompanyCount > 0) {
        this.gridCompany.gridView.setCurrent({ dataRow: this.selectedCompanyIndex, column: 'locCd' })
        await this.loadNationList(this.gridCompany.dataProvider.getJsonRow(this.selectedCompanyIndex).locKey)
      }
    },
    async loadNationList(upLocKey) {
      const params = {
        locTypeCd: 'NAT',
        upLocKey,
      }
      const rows = await this.$axios.$get(`/api/v1/test/location`, { params })

      this.gridNation.rowData = rows

      this.gridNation.dataProvider.setRows(this.gridNation.rowData)
      this.gridNation.gridView.refresh()
      this.gridNation.gridView.setTopItem(this.selectedNationIndex)

      this.totalNationCount = this.gridNation.gridView.getItemCount()
      if (this.totalNationCount > 0) {
        this.gridNation.gridView.setCurrent({ dataRow: this.selectedNationIndex, column: 'locCd' })
        await this.loadCityList(this.gridNation.dataProvider.getJsonRow(this.selectedNationIndex).locKey)
      }
    },
    async loadCityList(upLocKey) {
      const params = {
        locTypeCd: 'CTY',
        upLocKey,
      }
      const rows = await this.$axios.$get(`/api/v1/test/location`, { params })

      this.gridCity.rowData = rows

      this.gridCity.dataProvider.setRows(this.gridCity.rowData)
      this.gridCity.gridView.refresh()
      this.gridCity.gridView.setTopItem(0)

      this.totalCityCount = this.gridCity.gridView.getItemCount()
    },
    //endregion

    //region Grid Events
    onCurrentRowChangedCompanyGrid(grid, oldRow, newRow) {
      if (newRow > -1) {
        this.gridCompany.gridView.commit()
        const locKey = this.gridCompany.dataProvider.getJsonRow(newRow).locKey
        this.selectedCompanyKey = locKey
        this.gridNation.dataProvider.clearRows()
        this.gridCity.dataProvider.clearRows()
        if (locKey !== null && locKey !== '') {
          this.loadNationList(locKey)
        }
      }
    },

    onChangedNationGridCell(grid, index, value) {
      if (index.column === 'locNm') {
        grid.setValue(index.dataRow, 'locCd', value)
      }
    },

    onCurrentRowChangedNationGrid(grid, oldRow, newRow) {
      if (newRow > -1) {
        this.gridNation.gridView.commit()
        const locKey = this.gridNation.dataProvider.getJsonRow(newRow).locKey
        this.selectedNationKey = locKey
        this.gridCity.dataProvider.clearRows()
        if (locKey !== null && locKey !== '') {
          this.loadCityList(locKey)
        }
      }
    },

    onChangedCityGridCell(grid, index, value) {
      if (index.column === 'locTimeZoneCd') {
        for (let i = 0; i < this.codes.CO00000004.length; i += 1) {
          if (this.codes.CO00000004[i].cd === value) {
            grid.setValue(index.dataRow, 'gmtVal', this.codes.CO00000004[i].buf_2nd_cntn)
          }
        }
      }
    },
    //endregion

    //region Button Events
    async onClickSave() {
      this.gridCompany.gridView.commit()
      this.gridNation.gridView.commit()
      this.gridCity.gridView.commit()

      const insertList = []
      const updateList = []
      const deleteList = []

      const companyDataProvider = this.gridCompany.dataProvider
      const companyRawData = companyDataProvider.getJsonRows();
      for (let i = 0; i < companyDataProvider.getRowCount(); i += 1) {
        if (companyDataProvider.getRowState(i) === 'created') {
          insertList.push(companyRawData[i])
        } else if (companyDataProvider.getRowState(i) === 'updated') {
          updateList.push(companyRawData[i])
        } else if (companyDataProvider.getRowState(i) === 'deleted') {
          deleteList.push(companyRawData[i])
        }
      }

      const nationDataProvider = this.gridNation.dataProvider
      const nationRawData = nationDataProvider.getJsonRows();
      for (let i = 0; i < nationDataProvider.getRowCount(); i += 1) {
        if (nationDataProvider.getRowState(i) === 'created') {
          insertList.push(nationRawData[i])
        } else if (nationDataProvider.getRowState(i) === 'updated') {
          updateList.push(nationRawData[i])
        } else if (nationDataProvider.getRowState(i) === 'deleted') {
          deleteList.push(nationRawData[i])
        }
      }

      const cityDataProvider = this.gridCity.dataProvider
      const cityRawData = cityDataProvider.getJsonRows();
      for (let i = 0; i < cityDataProvider.getRowCount(); i += 1) {
        if (cityDataProvider.getRowState(i) === 'created') {
          insertList.push(cityRawData[i])
        } else if (cityDataProvider.getRowState(i) === 'updated') {
          updateList.push(cityRawData[i])
        } else if (cityDataProvider.getRowState(i) === 'deleted') {
          deleteList.push(cityRawData[i])
        }
      }

      const saveParam = {
        insertList,
        updateList,
        deleteList,
      }

      await this.$axios.post('/api/v1/test/location/save', saveParam).then((res) => {
        if (res.data.resultMsg === 'Success') {
          this.$toast.show(this.$t('MS00000011')) // 저장되었습니다.
          this.loadInitData()
        } else {
          this.$toast.show(this.$t('MS00000014'), { className: 'toast_error' }) // 오류가 발생했습니다.
        }
      })
    },
    onClickAddCompany() {
      this.gridCompany.gridView.commit()
      this.gridCompany.dataProvider.insertRows(0, [
        {
          locKey: '',
          locCd: '',
          locNm: '',
          locTimeZoneCd: '',
          locTypeCd: 'CPN',
          upLocKey: '',
          gmtVal: '',
          arryOrd: '',
        }
      ])
      this.totalCompanyCount = this.gridCompany.gridView.getItemCount()

      this.gridNation.dataProvider.clearRows();
      this.totalCompanyCount = this.gridCompany.gridView.getItemCount()
      this.gridCity.dataProvider.clearRows();
      this.totalCityCount = this.gridCity.gridView.getItemCount()
      this.selectedCompanyKey = ''
    },
    onClickDelCompany() {
      this.gridCompany.gridView.commit()
      this.gridCompany.dataProvider.setOptions({ softDeleting: true })
      const deleteRows = this.gridCompany.gridView.getCheckedRows()
      if (deleteRows.length < 1) {
        this.$toast.show(this.$t('삭제할 행을 선택하세요.'), { className: 'toast_error' })
        return
      }
      this.gridCompany.dataProvider.hideRows(deleteRows)
      this.gridCompany.dataProvider.removeRows(deleteRows)

      this.totalCompanyCount = this.gridCompany.gridView.getItemCount()
    },

    onClickAddNation() {
      this.gridCompany.gridView.commit()

      const selectedIndexes = this.gridCompany.gridView.getSelectedRows()
      const rawData = this.gridCompany.dataProvider.getJsonRows()
      if (selectedIndexes === null || selectedIndexes.length < 1) {
        this.$toast.show(this.$t('업체를 선택하세요'), { className: 'toast_error' })
        return
      } else if (rawData[selectedIndexes[0]].locKey === null || rawData[selectedIndexes[0]].locKey === '') {
        this.$toast.show(this.$t('업체 저장 후 등록하세요'), { className: 'toast_error' })
        return
      }

      this.gridNation.gridView.commit()
      this.gridNation.dataProvider.insertRows(0, [
        {
          locKey: '',
          locCd: '',
          locNm: '',
          locTimeZoneCd: '',
          locTypeCd: 'NAT',
          upLocKey: rawData[selectedIndexes[0]].locKey,
          gmtVal: '',
          arryOrd: '',
        },
      ])
      this.totalNationCount = this.gridNation.gridView.getItemCount()

      this.gridCity.dataProvider.clearRows();
      this.totalCityCount = this.gridCity.gridView.getItemCount()
      this.selectedNationKey = ''
    },
    onClickDelNation() {
      this.gridNation.gridView.commit()
      this.gridNation.dataProvider.setOptions({ softDeleting: true })
      const deleteRows = this.gridNation.gridView.getCheckedRows()
      if (deleteRows.length < 1) {
        this.$toast.show(this.$t('삭제할 행을 선택하세요.'), { className: 'toast_error' })
        return
      }
      this.gridNation.dataProvider.hideRows(deleteRows)
      this.gridNation.dataProvider.removeRows(deleteRows)

      this.totalNationCount = this.gridNation.gridView.getItemCount()
    },

    onClickAddCity() {
      this.gridNation.gridView.commit()

      const selectedIndexes = this.gridNation.gridView.getSelectedRows()
      const rawData = this.gridNation.dataProvider.getJsonRows()
      if (selectedIndexes === null || selectedIndexes.length < 1) {
        this.$toast.show(this.$t('국가를 선택하세요'), { className: 'toast_error' })
        return
      } else if (rawData[selectedIndexes[0]].locKey === null || rawData[selectedIndexes[0]].locKey === '') {
        this.$toast.show(this.$t('국가 저장 후 등록하세요'), { className: 'toast_error' })
        return
      }

      this.gridCity.gridView.commit()
      this.gridCity.dataProvider.insertRows(0, [
        {
          locKey: '',
          locCd: '',
          locNm: '',
          locTimeZoneCd: '',
          locTypeCd: 'CTY',
          upLocKey: rawData[selectedIndexes[0]].locKey,
          gmtVal: '',
          arryOrd: '',
        },
      ])
      this.totalCityCount = this.gridCity.gridView.getItemCount()
    },
    onClickDelCity() {
      this.gridCity.gridView.commit()
      this.gridCity.dataProvider.setOptions({ softDeleting: true })
      const deleteRows = this.gridCity.gridView.getCheckedRows()
      if (deleteRows.length < 1) {
        this.$toast.show(this.$t('삭제할 행을 선택하세요.'), { className: 'toast_error' })
        return
      }
      this.gridCity.dataProvider.hideRows(deleteRows)
      this.gridCity.dataProvider.removeRows(deleteRows)

      this.totalCityCount = this.gridCity.gridView.getItemCount()
    },
    //endregion

    //region Set Grid
    initCompanyGrid() {
      this.gridCompany.fields = [
        {
          fieldName: 'locKey',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locTypeCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'upLocKey',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locNm',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locTimeZoneCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'gmtVal',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'arryOrd',
          dataType: ValueType.TEXT,
        },
      ]

      this.gridCompany.dataProvider = new LocalDataProvider(false)
      this.gridCompany.dataProvider.setFields(this.gridCompany.fields)
      this.gridCompany.gridView = new GridView('companygrid')
      this.gridCompany.gridView.setDataSource(this.gridCompany.dataProvider)

      const companyColumns = [
        {
          header: '업체코드',
          name: 'locCd',
          fieldName: 'locCd',
          width: '100',
          styleCallback(grid, dataCell) {
            const returnObj = {}
            if (grid.getValue(dataCell.index.itemIndex, 'locKey') !== '') {
              returnObj.editable = false
            }
            return returnObj
          },
        },
        {
          header: '업체명',
          name: 'locNm',
          fieldName: 'locNm',
          width: '100',
        },
        {
          header: '정렬순서',
          name: 'arryOrd',
          fieldName: 'arryOrd',
          width: '100',
          editor: {
            type: 'number',
            maxLength: 4,
          },
        },
      ]

      this.gridCompany.gridView.setColumns(companyColumns)
      this.gridCompany.gridView.setFooters({ visible: false })
      this.gridCompany.gridView.setStateBar({ visible: false })
      this.gridCompany.gridView.setCheckBar({ visible: true })
      this.gridCompany.gridView.editOptions.editable = true
      this.gridCompany.gridView.displayOptions.selectionStyle = 'singleRow'

      this.gridCompany.gridView.header.height = 39
      this.gridCompany.gridView.displayOptions.rowHeight = 40
      this.gridCompany.gridView.footer.height = 40
      this.gridCompany.gridView.displayOptions.fitStyle = 'fill'
      this.gridCompany.gridView.rowIndicator.visible = true
      this.gridCompany.gridView.onCurrentRowChanged = this.onCurrentRowChangedCompanyGrid.bind(this)

    },
    initNationGrid() {
      this.gridNation.fields = [
        {
          fieldName: 'locKey',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locTypeCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'upLocKey',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locNm',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locTimeZoneCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'gmtVal',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'arryOrd',
          dataType: ValueType.TEXT,
        },
      ]

      this.gridNation.dataProvider = new LocalDataProvider(false)
      this.gridNation.dataProvider.setFields(this.gridNation.fields)
      this.gridNation.gridView = new GridView('nationgrid')
      this.gridNation.gridView.setDataSource(this.gridNation.dataProvider)

      const nationColumns = [
        {
          header: '국가명',
          name: 'locNm',
          fieldName: 'locNm',
          width: '100',
          lookupDisplay: true,
          values: this.selCO00000003.cd,
          labels: this.selCO00000003.cd_nm,
          editor: {
            type: 'dropdown',
            domainOnly: true,
            textReadOnly: true,
            displayLabels: 'label',
          },
          styleCallback(grid, dataCell) {
            const returnObj = {}
            if (grid.getValue(dataCell.index.itemIndex, 'locKey') !== null
              && grid.getValue(dataCell.index.itemIndex, 'locKey') !== '') {
              returnObj.editable = false
            }
            return returnObj
          },
        },
        {
          header: '국가코드',
          name: 'locCd',
          fieldName: 'locCd',
          width: '140',
          lookupDisplay: true,
          editable: false,
        },
        {
          header: '정렬순서',
          name: 'arryOrd',
          fieldName: 'arryOrd',
          width: '100',
          editor: {
            type: 'number',
            maxLength: 4,
          },
        },
      ]

      this.gridNation.gridView.setColumns(nationColumns)
      this.gridNation.gridView.setFooters({ visible: false })
      this.gridNation.gridView.setStateBar({ visible: false })
      this.gridNation.gridView.setCheckBar({ visible: true })
      this.gridNation.gridView.editOptions.editable = true
      this.gridNation.gridView.displayOptions.selectionStyle = 'singleRow'

      this.gridNation.gridView.header.height = 39
      this.gridNation.gridView.displayOptions.rowHeight = 40
      this.gridNation.gridView.footer.height = 40
      this.gridNation.gridView.displayOptions.fitStyle = 'fill'
      this.gridNation.gridView.rowIndicator.visible = true

      this.gridNation.gridView.onEditChange = this.onChangedNationGridCell.bind(this)
      this.gridNation.gridView.onCurrentRowChanged = this.onCurrentRowChangedNationGrid.bind(this)
    },
    initCityGrid() {
      this.gridCity.fields = [
        {
          fieldName: 'locKey',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locTypeCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'upLocKey',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locNm',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'locTimeZoneCd',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'gmtVal',
          dataType: ValueType.TEXT,
        }, {
          fieldName: 'arryOrd',
          dataType: ValueType.TEXT,
        },
      ]

      this.gridCity.dataProvider = new LocalDataProvider(false)
      this.gridCity.dataProvider.setFields(this.gridCity.fields)
      this.gridCity.gridView = new GridView('citygrid')
      this.gridCity.gridView.setDataSource(this.gridCity.dataProvider)

      const cityColumns = [
        {
          header: '도시코드',
          name: 'locCd',
          fieldName: 'locCd',
          width: '100',
          styleCallback(grid, dataCell) {
            const returnObj = {}
            if (grid.getValue(dataCell.index.itemIndex, 'locKey') !== '') {
              returnObj.editable = false
            }
            return returnObj
          },
        },
        {
          header: '도시명',
          name: 'locNm',
          fieldName: 'locNm',
          width: '100',
        },
        {
          header: '타임존',
          name: 'locTimeZoneCd',
          fieldName: 'locTimeZoneCd',
          width: '140',
          lookupDisplay: true,
          values: this.selCO00000004.cd,
          labels: this.selCO00000004.cd_nm,
          editor: {
            type: 'dropdown',
            domainOnly: true,
            textReadOnly: false,
            displayLabels: 'label',
          },
        },
        {
          header: 'GMT',
          name: 'gmtVal',
          fieldName: 'gmtVal',
          width: '100',
        },
        {
          header: '정렬순서',
          name: 'arryOrd',
          fieldName: 'arryOrd',
          width: '100',
          editor: {
            type: 'number',
            maxLength: 4,
          },
        },
      ]

      this.gridCity.gridView.setColumns(cityColumns)
      this.gridCity.gridView.setFooters({ visible: false })
      this.gridCity.gridView.setStateBar({ visible: false })
      this.gridCity.gridView.setCheckBar({ visible: true })
      this.gridCity.gridView.editOptions.editable = true
      this.gridCity.gridView.displayOptions.selectionStyle = 'singleRow'

      this.gridCity.gridView.header.height = 39
      this.gridCity.gridView.displayOptions.rowHeight = 40
      this.gridCity.gridView.footer.height = 40
      this.gridCity.gridView.displayOptions.fitStyle = 'fill'
      this.gridCity.gridView.rowIndicator.visible = true

      this.gridCity.gridView.onEditChange = this.onChangedCityGridCell.bind(this)
    },
    //endregion
  },
}
</script>
<style lang="scss" scoped></style>
