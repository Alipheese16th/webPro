package com.kist.portal.test.user.mapper;

import com.kist.portal.test.user.dto.TestUserDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TestUserMapper {

    List<TestUserDto> selectUserList(TestUserDto param);

    String selectUserMainKey();

    int insertUserMain(TestUserDto param);

    int updateUserMain(TestUserDto param);

    int insertUserDetail(TestUserDto param);

    int deleteUserDetail(TestUserDto param);
}
