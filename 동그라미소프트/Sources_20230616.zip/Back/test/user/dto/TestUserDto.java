package com.kist.portal.test.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestUserDto {
    private String usrKey;
    private String usrId;
    private String usrRgstDt;
    private String usgYn;
    private String delYn;
    private String crtDtm;
    private String uptDtm;
    private String usrNm;
    private String usrEngNm;

    private String rgstStartDt;
    private String rgstEndDt;

    private String resultMsg;
}
