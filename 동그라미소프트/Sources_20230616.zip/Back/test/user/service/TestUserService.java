package com.kist.portal.test.user.service;

import com.kist.portal.test.user.dto.TestUserDto;

import java.util.List;

public interface TestUserService {

    List<TestUserDto> selectUserList(TestUserDto param);

    TestUserDto saveUser(TestUserDto param);
}
