package com.kist.portal.test.user.service;

import com.kist.portal.common.utils.Constant;
import com.kist.portal.test.user.dto.TestUserDto;
import com.kist.portal.test.user.mapper.TestUserMapper;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TestUserServiceImpl implements TestUserService {

	@NonNull
	private final TestUserMapper mapper;

	@Override
	public List<TestUserDto> selectUserList(TestUserDto param) {
		return mapper.selectUserList(param);
	}

	@Override
	public TestUserDto saveUser(TestUserDto param) {
		int cnt = 0;
		if (param != null) {
			// Delete
			if ("Y".equals(param.getDelYn())) {
				cnt += mapper.updateUserMain(param);
				cnt += mapper.deleteUserDetail(param);
			}
			// Update
			else if (param.getUsrKey() != null && !"".equals(param.getUsrKey())) {
				cnt += mapper.updateUserMain(param);
				cnt += mapper.insertUserDetail(param);
			}
			// Insert
			else if (param.getUsrKey() == null || "".equals(param.getUsrKey())) {
				String userKey = mapper.selectUserMainKey();
				param.setUsrKey(userKey);

				cnt += mapper.insertUserMain(param);
				cnt += mapper.insertUserDetail(param);
			}
		}

		param.setResultMsg(cnt > 0 ? Constant.SUCCESS : Constant.FAIL);
		return param;
	}
}
