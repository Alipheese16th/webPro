package com.kist.portal.test.user.rest;

import com.kist.portal.test.user.dto.TestUserDto;
import com.kist.portal.test.user.service.TestUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/test")
public class TestUserController {

	@Autowired
	private TestUserService userService;

	@GetMapping("/user/list")
	public ResponseEntity<List<TestUserDto>> selectUserList(@ModelAttribute TestUserDto param) {
		return new ResponseEntity<>(userService.selectUserList(param), HttpStatus.OK);
	}

	@PostMapping("/user/save")
	@Transactional
	public ResponseEntity<?> updateUserList(@RequestBody TestUserDto param) {
		TestUserDto result = userService.saveUser(param);

		return new ResponseEntity<>(result, HttpStatus.OK);
	}
}
