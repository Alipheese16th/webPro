<template>
  <v-dialog v-model="dialog" :eager="true" persistent width="1000px">
    <v-card class="container_pop">
      <v-toolbar flat class="mb-6">
        <v-toolbar-title>{{ $t('사용자 선택') }}</v-toolbar-title>
        <v-spacer></v-spacer>
        <!-- 닫기 -->
        <v-btn icon class="btn_pop_cls" @click="close()">{{ $t('닫기') }}</v-btn>
      </v-toolbar>
      <div class="container_pop_section">
        <div class="pop_article">
          <div class="container_sch">
            <v-row>
              <v-col cols="1">
                <!--사용자ID-->
                <div class="label_tit">{{ $t('사용자ID') }}</div>
              </v-col>
              <v-col cols="3">
                <!--입력하세요-->
                <v-text-field v-model="searchData.usrId" outlined single-line :hide-details="true" dense
                              :placeholder="$t('LB00000033')" height="30" maxlength="19" @keypress.enter="select()" />
              </v-col>
              <v-col cols="1">
                <!--사용자명-->
                <div class="label_tit">{{ $t('사용자명') }}</div>
              </v-col>
              <v-col cols="3">
                <!--입력하세요-->
                <v-text-field v-model="searchData.usrNm" outlined single-line :hide-details="true" dense
                              :placeholder="$t('LB00000033')" height="30" maxlength="99" @keypress.enter="select()" />
              </v-col>
              <v-col cols="4" class="right">
                <div class="sch_btn">
                  <!--초기화-->
                  <v-btn color="" outlined height="36" @click="reset">{{ $t('초기화') }}</v-btn>
                  <!--검색-->
                  <v-btn color="primary" depressed height="36" @click="select">{{ $t('검색') }}</v-btn>
                </div>
              </v-col>
            </v-row>
          </div>
          <div class="group_padd"></div>
          <div class="realgrid_container">
            <div id="usergrid" style="width: 100%; height: 281px"></div>
          </div>
        </div>
      </div>
      <div class="group_padd"></div>
      <v-card-actions class="pop_btn">
        <v-btn color="primary" depressed width="120" height="40" @click="onClickSelect">{{ $t('선택') }}</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { GridView, LocalDataProvider, ValueType } from 'realgrid'

export default {
  components: {
  },
  props: {
  },
  data() {
    return {
      dialog: false,
      totalcnt: 0,
      searchData: {
        usrId: '',
        usrNm: '',
        usgYn: 'Y',
      },
      gridUser: {
        dataProvider: null,
        gridView: null,
        field: [],
        rowData: [],
      },

      dataProvider: null,
      gridView: null,
      field: [],
      rowData: [],
    }
  },
  mounted() {
    console.log('mounted pop')
    this.initGrid()
  },
  methods: {
    async select() {
      const rows = await this.$axios.$get(`/api/v1/test/user/list`, { params: this.searchData })

      this.gridUser.rowData = rows

      this.gridUser.dataProvider.setRows(this.gridUser.rowData)
      this.gridUser.gridView.refresh()
      this.gridUser.gridView.setTopItem(0)
      this.totalcnt = this.gridUser.gridView.getItemCount()
    },
    reset() {
      this.searchData = {
        usrId: '',
        usrNm: '',
        usgYn: 'Y',
      }
      this.gridUser.gridView.refresh()
    },

    initGrid() {
      // 그리드 세팅
      this.gridUser.fields = [
        {
          fieldName: 'usrKey',
          dataType: ValueType.TEXT,
        },
        {
          fieldName: 'usrId',
          dataType: ValueType.TEXT,
        },
        {
          fieldName: 'usrNm',
          dataType: ValueType.TEXT,
        },
        {
          fieldName: 'usrEngNm',
          dataType: ValueType.TEXT,
        },
        {
          fieldName: 'usrRgstDt',
          dataType: ValueType.TEXT,
        },
        {
          fieldName: 'usgYn',
          dataType: ValueType.TEXT,
        },
      ]

      this.gridUser.dataProvider = new LocalDataProvider(false)
      this.gridUser.dataProvider.setFields(this.gridUser.fields)
      this.gridUser.gridView = new GridView('usergrid')
      this.gridUser.gridView.setDataSource(this.gridUser.dataProvider)

      const columns = [
        {
          header: '사용자ID',
          name: 'usrId',
          fieldName: 'usrId',
          width: '100',
          editable: false,
        },
        {
          header: '사용자명',
          name: 'usrNm',
          fieldName: 'usrNm',
          width: '100',
          editable: false,
        },
        {
          header: '사용자영문명',
          name: 'usrEngNm',
          fieldName: 'usrEngNm',
          width: '140',
          editable: false,
        },
        {
          header: '사용자등록일',
          name: 'usrRgstDt',
          fieldName: 'usrRgstDt',
          width: '100',
          editable: false,
        },
        {
          header: '사용여부',
          name: 'usgYn',
          fieldName: 'usgYn',
          width: '100',
          editable: false,
        },
      ]

      this.gridUser.gridView.setColumns(columns)
      this.gridUser.gridView.setFooters({ visible: false })
      this.gridUser.gridView.setStateBar({ visible: false })
      this.gridUser.gridView.setCheckBar({ visible: false })
      this.gridUser.gridView.editOptions.editable = false
      this.gridUser.gridView.displayOptions.selectionStyle = 'singleRow'

      this.gridUser.gridView.header.height = 39
      this.gridUser.gridView.displayOptions.rowHeight = 40
      this.gridUser.gridView.footer.height = 40
      this.gridUser.gridView.displayOptions.fitStyle = 'fill'
      this.gridUser.gridView.rowIndicator.visible = true

      this.gridUser.gridView.onCellDblClicked = function (grid, clickData) {
        this.selectUser(clickData.dataRow)
      }.bind(this)

    },

    selectUser(rowIndex) {
      this.$emit('selectUser', this.gridUser.dataProvider.getJsonRow(rowIndex))
      this.dialog = false
      this.reset()
    },

    open() {
      this.dialog = true
    },

    close() {
      this.$emit('close');
      this.dialog = false
    },

    onClickSelect() {
      const selectedData = this.gridUser.gridView.getSelectionData()
      if (selectedData !== null && selectedData.length > 0) {
        this.$emit('selectUser', selectedData[0])
        this.dialog = false
        this.reset()
      } else {
        this.$toast.show(this.$t('사용자를 선택하세요'), { className: 'toast_error' })
      }
    },
  },
}
</script>
<style lang="scss" scoped></style>
