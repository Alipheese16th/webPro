<template>
  <div>
    <div class="location">
      <!--테스트 메뉴--><!--사용자 관리-->
      <span>Home > {{ $t('테스트 메뉴') }} > {{ $t('사용자 관리') }}</span>
    </div>
    <div class="work_title">
      <h2>{{ $t('사용자 조회') }}</h2>
    </div>
    <div class="container_sch">
      <v-row>
        <v-col cols="10">
          <v-container>
            <v-row>
              <v-col cols="1">
                <!--사용자ID-->
                <div class="label_tit">{{ $t('사용자ID') }}</div>
              </v-col>
              <v-col cols="3">
                <!--입력하세요-->
                <v-text-field v-model="searchData.usrId" outlined single-line :hide-details="true" dense
                  :placeholder="$t('LB00000033')" height="30" maxlength="19" @keypress.enter="select()" />
              </v-col>
              <v-col cols="1">
                <!--사용자명-->
                <div class="label_tit">{{ $t('사용자명') }}</div>
              </v-col>
              <v-col cols="3">
                <!--입력하세요-->
                <v-text-field v-model="searchData.usrNm" outlined single-line :hide-details="true" dense
                  :placeholder="$t('LB00000033')" height="30" maxlength="99" @keypress.enter="select()" />
              </v-col>
              <v-col cols="1">
                <!--사용여부-->
                <div class="label_tit">{{ $t('사용여부') }}</div>
              </v-col>
              <v-col cols="3">
                <v-select v-model="searchData.usgYn" label="ALL" item-text="cd_nm" item-value="cd" :items="use_yn_cd"
                          outlined single-line :hide-details="true" dense height="30" />
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="1">
                <!--사용자등록일-->
                <div class="label_tit">{{ $t('사용자등록일') }}</div>
              </v-col>
              <v-col cols="3" style="display: flex">
                <v-menu v-model="menu1" :close-on-content-click="false" :nudge-right="40" min-width="290px">
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                      v-model="searchData.rgstStartDt"
                      prepend-icon="event"
                      readonly
                      outlined
                      :hide-details="true"
                      dense
                      height="30"
                      v-bind="attrs"
                      class="comp_calendar mr-1"
                      v-on="on"
                    />
                  </template>
                  <v-date-picker v-model="searchData.rgstStartDt" :max="searchData.rgstEndDt" no-title @input="menu1 = false" />
                </v-menu>
                <v-menu v-model="menu2" :close-on-content-click="false" :nudge-right="40" min-width="290px">
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                      v-model="searchData.rgstEndDt"
                      prepend-icon="event"
                      readonly
                      outlined
                      :hide-details="true"
                      dense
                      height="30"
                      v-bind="attrs"
                      class="comp_calendar"
                      v-on="on"
                    />
                  </template>
                  <v-date-picker v-model="searchData.rgstEndDt" :min="searchData.rgstStartDt" no-title @input="menu2 = false" />
                </v-menu>
              </v-col>
            </v-row>
          </v-container>
        </v-col>
        <v-col cols="2">
          <div class="sch_btn">
            <!--초기화-->
            <v-btn color="" outlined height="36" @click="reset">{{ $t('초기화') }}</v-btn>
            <!--검색-->
            <v-btn color="primary" depressed height="36" @click="select">{{ $t('검색') }}</v-btn>
          </div>
        </v-col>
      </v-row>
    </div>
    <div class="group_padd"></div>
    <div class="realgrid_container">
      <div class="sub_title">
        <h3>{{ $t('사용자 목록') }}</h3>
      </div>
      <div class="grid_header">
        <!--총--><!--건-->
        <div class="grid_header_left">{{ $t('총') }} {{ totalcnt }}{{ $t('건') }}</div>
        <div>
          <!--등록-->
          <v-btn color="" outlined height="28" @click="onClickRegister">{{ $t('등록') }}</v-btn>
        </div>
      </div>
      <div id="realgrid" style="width: 100%; height: 481px"></div>
    </div>
  </div>
</template>

<script>
import { GridView, LocalDataProvider, ValueType } from 'realgrid'

export default {
  meta: {
    title: '사용자 관리',
    key(route) {
      return `/test/usermgt/${route.params.catalog}`
    },
  },
  components: {
  },
  data() {
    return {
      dialog: {
        frmData: {},
        isOpen: false,
        isModify: false
      },
      savedatas: [],
      totalcnt: 0,
      searchData: {
        usrId: '',
        usrNm: '',
        usgYn: '',
        rgstStartDt: '',
        rgstEndDt: '',
      },
      grid: {
        dataProvider: null,
        gridView: null,
        field: [],
        rowData: []
      },
      use_yn_cd: [
        { cd: '', cd_nm: 'ALL' },
        { cd: 'Y', cd_nm: 'Y' },
        { cd: 'N', cd_nm: 'N' },
      ],
      menu1: false,
      menu2: false,
    }
  },
  async beforePageLeave(tab, type) {
  },
  created() {
    if (this.$route.params.searchData !== undefined && this.$route.params.searchData !== null) {
      this.searchData = this.$route.params.searchData
    }
  },
  mounted() {
    // 그리드 세팅
    this.grid.fields = [
      {
        fieldName: 'usrKey',
        dataType: ValueType.TEXT,
      },
      {
        fieldName: 'usrId',
        dataType: ValueType.TEXT,
      },
      {
        fieldName: 'usrNm',
        dataType: ValueType.TEXT,
      },
      {
        fieldName: 'usrEngNm',
        dataType: ValueType.TEXT,
      },
      {
        fieldName: 'usrRgstDt',
        dataType: ValueType.TEXT,
      },
      {
        fieldName: 'usgYn',
        dataType: ValueType.TEXT,
      },
    ]

    this.grid.dataProvider = new LocalDataProvider(false)
    this.grid.dataProvider.setFields(this.grid.fields)
    this.grid.gridView = new GridView('realgrid')
    this.grid.gridView.setDataSource(this.grid.dataProvider)

    const columns = [
      {
        header: '사용자ID',
        name: 'usrId',
        fieldName: 'usrId',
        width: '100',
        editable: false,
        styleName: 'link',
      },
      {
        header: '사용자명',
        name: 'usrNm',
        fieldName: 'usrNm',
        width: '100',
        editable: false,
      },
      {
        header: '사용자영문명',
        name: 'usrEngNm',
        fieldName: 'usrEngNm',
        width: '140',
        editable: false,
      },
      {
        header: '사용자등록일',
        name: 'usrRgstDt',
        fieldName: 'usrRgstDt',
        width: '100',
        editable: false,
      },
      {
        header: '사용여부',
        name: 'usgYn',
        fieldName: 'usgYn',
        width: '100',
        editable: false,
      },
    ]

    this.grid.gridView.setColumns(columns)
    this.grid.gridView.setFooters({ visible: false })
    this.grid.gridView.setStateBar({ visible: false })
    this.grid.gridView.setCheckBar({ visible: false })
    this.grid.gridView.editOptions.editable = true
    this.grid.gridView.displayOptions.selectionStyle = 'singleRow'

    this.grid.gridView.header.height = 39
    this.grid.gridView.displayOptions.rowHeight = 40
    this.grid.gridView.footer.height = 40
    this.grid.gridView.displayOptions.fitStyle = 'fill'
    this.grid.gridView.rowIndicator.visible = true
    this.grid.gridView.onCellClicked = this.rowClick

    this.select()
  },
  methods: {
    rowClick(grid, clickData) {
      if (clickData.fieldName === 'usrId') {
        this.grid.gridView.commit()
        const usrKey = this.grid.dataProvider.getValue(clickData.dataRow, 'usrKey')

        this.$router.push({
          name: 'test-usercntn-usercntn',
          params: {
            usercntn: usrKey,
            searchData: this.searchData,
          },
        })
      }
    },
    onClickRegister() {
      this.$router.push({
        name: 'test-usercntn-usercntn',
        params: {
          searchData: this.searchData,
        },
      })
    },
    async select() {
      const rows = await this.$axios.$get(`/api/v1/test/user/list`, { params: this.searchData })

      this.grid.rowData = rows

      this.grid.dataProvider.setRows(this.grid.rowData)
      this.grid.gridView.refresh()
      this.grid.gridView.setTopItem(0)
      this.totalcnt = this.grid.gridView.getItemCount()
    },
    reset() {
      this.grid.gridView.commit()
      this.searchData = {
        usrId: '',
        usrNm: '',
        usgYn: '',
        rgstStartDt: '',
        rgstEndDt: '',
      }
    },
  },
}
</script>
<style lang="scss" scoped></style>
