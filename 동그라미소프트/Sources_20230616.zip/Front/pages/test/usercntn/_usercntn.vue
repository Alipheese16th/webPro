<template>
  <div>
    <div class="location">
      <span>Home > {{ $t('테스트 메뉴') }} > {{ $t('사용자 상세') }}</span>
    </div>
    <div class="work_title">
      <h2>{{ $t('사용자 상세') }}</h2>
    </div>
    <div class="container_detail">
      <div class="sub_title">
        <!-- 기본정보 -->
        <h3>{{ $t('기본정보') }}</h3>
      </div>
      <v-row>
        <v-col cols="12">
          <v-container>
            <v-row>
              <v-col cols="1">
                <!--사용자ID-->
                <div class="label_tit essn">{{ $t('사용자ID') }}</div>
              </v-col>
              <v-col cols="3">
                <!--입력하세요-->
                <v-text-field ref="usrId" v-model="userData.usrId" outlined single-line :hide-details="true" dense :readonly="!isReadonlyUserId"
                  :placeholder="$t('LB00000033')" height="30" maxlength="19"></v-text-field>
              </v-col>
              <v-col cols="1">
                <!--사용자명-->
                <div class="label_tit essn">{{ $t('사용자명') }}</div>
              </v-col>
              <v-col cols="3">
                <!--입력하세요-->
                <v-text-field ref="usrNm" v-model="userData.usrNm" outlined single-line :hide-details="true" dense
                  :placeholder="$t('LB00000033')" height="30" maxlength="99"></v-text-field>
              </v-col>
              <v-col cols="1">
                <!--사용자영문명-->
                <div class="label_tit">{{ $t('사용자영문명') }}</div>
              </v-col>
              <v-col cols="3">
                <!--입력하세요-->
                <v-text-field v-model="userData.usrEngNm" outlined single-line :hide-details="true" dense
                  :placeholder="$t('LB00000033')" height="30" maxlength="99"></v-text-field>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="1">
                <!--사용여부-->
                <div class="label_tit">{{ $t('사용여부') }}</div>
              </v-col>
              <v-col cols="3">
                <v-select ref="usgYn" v-model="userData.usgYn" label="ALL" item-text="cd_nm" item-value="cd" :items="use_yn_cd"
                  outlined single-line :hide-details="true" dense height="30"></v-select>
              </v-col>
              <v-col cols="1">
                <!--사용자등록일-->
                <div class="label_tit">{{ $t('사용자등록일') }}</div>
              </v-col>
              <v-col cols="7">
                <div class="label_con">{{ userData.usrRgstDt }}</div>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="1">
                <!--최초등록일시-->
                <div class="label_tit">{{ $t('최초등록일시') }}</div>
              </v-col>
              <v-col cols="3">
                <div class="label_con">{{ userData.crtDtm }}</div>
              </v-col>
              <v-col cols="1">
                <!--최종수정일시-->
                <div class="label_tit">{{ $t('최종수정일시') }}</div>
              </v-col>
              <v-col cols="7">
                <div class="label_con">{{ userData.uptDtm }}</div>
              </v-col>
            </v-row>
          </v-container>
        </v-col>
      </v-row>
    </div>
    <div class="group_padd"></div>
    <div class="container_button">
      <!--저장-->
      <v-btn v-show="isVisibleDeleteButton" depressed width="120" color="primary" height="40" @click="onClickDelete">{{ $t('삭제') }}</v-btn>
      <!--저장-->
      <v-btn depressed width="120" color="primary" height="40" @click="onClickSave">{{ $t('저장') }}</v-btn>
      <!--목록-->
      <v-btn outlined width="120" height="40" @click="onClickList">{{ $t('목록') }}</v-btn>
    </div>
  </div>
</template>

<script>
import { GridView, LocalDataProvider, ValueType } from 'realgrid'

export default {
  meta: {
    title: '사용자 상세',
    key(route) {
      return `/test/usermgt/${route.params.catalog}`
    },
  },
  components: {
  },
  data() {
    return {
      searchData: {},
      userData: {
        usrKey: '',
        usrId:  '',
        usrNm: '',
        usrEngNm: '',
        usgYn: 'Y',
        usrRgstDt: '',
        crtDtm: '',
        uptDtm: '',
        delYn: '',
      },
      emptyData: {
        usrKey: '',
        usrId:  '',
        usrNm: '',
        usrEngNm: '',
        usgYn: 'Y',
        usrRgstDt: '',
        crtDtm: '',
        uptDtm: '',
        delYn: '',
      },
      grid: {
        dataProvider: null,
        gridView: null,
        field: [],
        rowData: []
      },
      use_yn_cd: [
        { cd: 'Y', cd_nm: 'Y' },
        { cd: 'N', cd_nm: 'N' },
      ],
    }
  },
  async beforePageLeave(tab, type) {
    if (this.userData.delYn !== 'Y' && JSON.stringify(this.emptyData) !== JSON.stringify(this.userData)) {
      const res = await this.$confirm(this.$t('MS00000060'))
      return new Promise((resolve, reject) => {
        if (res) {
          resolve()
        } else {
          // eslint-disable-next-line prefer-promise-reject-errors
          reject('reject')
        }
      })
    }
  },
  computed: {
    isReadonlyUserId() {
      return this.userData.usrKey === null || this.userData.usrKey === ''
    },
    isVisibleDeleteButton() {
      return this.userData.usrKey !== null && this.userData.usrKey !== ''
    },
  },
  created() {
    if (this.$route.params.searchData !== undefined && this.$route.params.searchData !== null) {
      this.searchData = this.$route.params.searchData
    }
  },
  mounted() {
    if (this.$route.params.usercntn !== undefined && this.$route.params.usercntn !== null && this.$route.params.usercntn !== '') {
      this.userData.usrKey = this.$route.params.usercntn

      this.select()
    }
  },
  methods: {
    async select() {
      const rows = await this.$axios.$get(`/api/v1/test/user/list`, { params: this.userData })

      if (rows !== null && rows.length > 0) {
        this.userData = rows[0]
        this.emptyData = JSON.parse(JSON.stringify(this.userData))
      }
    },
    async onClickSave() {
      if ((this.userData.usrKey !== null && this.userData.usrKey !== '') && JSON.stringify(this.emptyData) === JSON.stringify(this.userData)) {
        this.$toast.show(this.$t('변경된 내용이 없습니다.'), { className: 'toast_error' })
        return
      }

      if (!this.checkValidity()) {
        return
      }

      if (this.userData.usrKey === null || this.userData.usrKey === '') {
        const tempData = {
          usrId: this.userData.usrId,
        }
        const rows = await this.$axios.$get(`/api/v1/test/user/list`, { params: tempData })
        if (rows.length > 0) {
          this.$toast.show(this.$t('동일한 사용자ID가 존재합니다.'), { className: 'toast_error' })
          return
        }
      }

      // 저장 여부 확인
      const confirm = await this.$confirm(this.$t('MS00000010')) // 저장하시겠습니까?

      if (confirm) {
        await this.$axios.post('/api/v1/test/user/save', this.userData).then((res) => {
          if (res.data.resultMsg === 'Success') {
            this.userData.usrKey = res.data.usrKey
            this.$toast.show(this.$t('MS00000011')) // 저장되었습니다.
            this.select()
          } else {
            this.$toast.show(this.$t('MS00000014'), { className: 'toast_error' }) // 오류가 발생했습니다.
          }
        })
      }
    },
    async onClickDelete() {
      // 저장 여부 확인
      const res = await this.$confirm(this.$t('삭제하시겠습니까?'))

      if (res) {
        this.userData.delYn = 'Y'
        await this.$axios.post('/api/v1/test/user/save', this.userData).then((res) => {
          if (res.data.result === 'Success') {
            this.$toast.show(this.$t('삭제되었습니다.'))
            this.onClickList()
          } else {
            this.$toast.show(this.$t('MS00000014'), { className: 'toast_error' }) // 오류가 발생했습니다.
          }
        })
      }
    },
    checkValidity() {
      if (this.userData.usrId === '') {
        this.$toast.show(this.$t('사용자ID를 입력하세요.'), { className: 'toast_error' })
        this.$refs.usrId.focus()
        return false
      } else if (/[\s]/g.test(this.userData.usrId)) {
        this.$toast.show(this.$t('사용자ID에 공백문자는 사용할 수 없습니다.'), { className: 'toast_error' })
        this.$refs.usrId.focus()
        return false
      } else if (!/^[A-Za-z0-9+]*$/.test(this.userData.usrId)) {
        this.$toast.show(this.$t('사용자ID는 영문, 숫자로 작성해주세요.'), { className: 'toast_error' })
        this.$refs.usrId.focus()
        return false
      } else if (this.userData.usrNm === '') {
        this.$toast.show(this.$t('사용자명을 입력하세요.'), { className: 'toast_error' })
        this.$refs.usrNm.focus()
        return false
      } else if (this.userData.usgYn === '') {
        this.$toast.show(this.$t('사용여부를 선택하세요.'), { className: 'toast_error' })
        this.$refs.usgYn.focus()
        return false
      }
      return true
    },
    onClickList() {
      this.$router.push({
        name: 'test-usermgt',
        params: {
          searchData: this.searchData,
        },
      })
    },
  },
}
</script>
<style lang="scss" scoped></style>
